$(function(){
		// initiate tool tip
		$('.normaltip').aToolTip();
});
