package com.infosys.infytel.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.infytel.entity.Plan;

public interface PlanRepository extends JpaRepository<Plan, Integer> {
	


}
